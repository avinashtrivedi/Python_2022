test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> booktitles==['SecretOfChimneys', 'DeathInTheClouds', 'SparklingCyanide', 'HickoryDickoryDock', 'AtBertramsHotel', 'Curtain']\nTrue",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
