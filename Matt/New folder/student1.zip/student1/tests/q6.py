test = {'name': 'q6', 'points': None, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
