test = {'name': 'q5', 'points': None, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
