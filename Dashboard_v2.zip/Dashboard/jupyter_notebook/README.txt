1) open dashboard.ipynb in jupyter notebook

2) click on the local host link (http://127.0.0.1:7867/  or something like this)